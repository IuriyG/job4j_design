[![Build Status](https://travis-ci.org/IuriyG/job4j_design.svg?branch=master)](https://travis-ci.org/IuriyG/job4j_design)
![GitHub language count](https://img.shields.io/github/languages/count/IuriyG/job4j_design)
[![jdk14](https://img.shields.io/badge/JDK-14-blue.svg)](http://jdk.java.net/14/)
![GitHub top language](https://img.shields.io/github/languages/top/IuriyG/job4j_design)
![Lines of code](https://img.shields.io/tokei/lines/github/IuriyG/job4j_design)
![GitHub commit activity](https://img.shields.io/github/commit-activity/m/IuriyG/job4j_design)
[![CodeFactor](https://www.codefactor.io/repository/github/iuriyg/job4j_design/badge)](https://www.codefactor.io/repository/github/iuriyg/job4j_design)
[![codecov](https://codecov.io/gh/IuriyG/job4j_design/branch/master/graph/badge.svg)](https://codecov.io/gh/IuriyG/job4j_design)

# Уровень ["Junior".](https://job4j.ru/courses/java_with_zero_to_job.html)

Уровень <b>"Junior"</b> - В этом уровне мы создадим парсер вакансий популярного сайта. Узнаем, что внутри каждой из коллекций и почему одна коллекция работает быстрее, чем другая. Познакомимся с анализом алгоритмов. Узнаем, как работают самые важные алгоритмы. Познакомимся с концепциями ввода-вывода. Научимся использовать базы данных и хранить ценную информацию в них. После этого уровня можно претендовать на позиции Junior Java разработчик.